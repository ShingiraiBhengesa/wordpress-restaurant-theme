<?php
/**
 * @package ciy_parallax_theme
 * 
 * Add all your dashboard and backend functions here
 */
add_theme_support('post-thumbnails');
add_post_type_support('page', 'excerpt');