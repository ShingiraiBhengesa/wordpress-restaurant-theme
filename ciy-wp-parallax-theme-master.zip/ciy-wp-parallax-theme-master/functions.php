<?php
/**
 * @package ciy_parallax_theme
 * 
 * Require all your other functions files here
 */

require get_template_directory() . '/inc/menus.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/dashboard-functions.php';
require get_template_directory() . '/inc/pages-customizer.php';