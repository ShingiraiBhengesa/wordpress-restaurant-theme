function openSideMenu(){
    document.getElementById('navbar__side-menu').style.width = '250px';
    document.getElementById('main').style.marginLeft = '250px';
}

function closeSideMenu(){
    document.getElementById('navbar__side-menu').style.width = '0px';
    document.getElementById('main').style.marginLeft = '0px';
}